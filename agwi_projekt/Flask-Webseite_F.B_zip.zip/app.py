import time

from flask import Flask, request, session
from flask import render_template
from geschaeftsobjekte import Produkt, Adresse, User, Halle, Trainer, Bewertung

#Hashmaps hier
halle_hashmap = {
    1: Halle(halleId=1, name="Halle 1", opening_time=time.strftime("%H:%M:%S", time.localtime()),
             address=Adresse(adresseId=1, name="Hauptstraße 123")),
    2: Halle(halleId=2, name="Halle 2", opening_time=time.strftime("%H:%M:%S", time.localtime()),
             address=Adresse(adresseId=2, name="Bergstraße 42")),
}

trainer_hashmap = {
    1: Trainer(trainerId=1, name="John Doe", email="john.doe@example.com", birthday="1990-05-15"),
    2: Trainer(trainerId=2, name="Jane Smith", email="jane.smith@example.com", birthday="1985-03-22"),
}





app = Flask(__name__)

app.secret_key = "8474747"

@app.route('/')
def hello_world():  # put application's code here
    mycounter = session.get("counter", 0)  # Defaults to 0 if 'counter' is not in session
    mycounter += 1

    session['counter'] = mycounter
    print(mycounter)
    return render_template('login.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    return render_template('login.html')

@app.route('/produkte')
def zeige_produkte():
    return render_template('produkte.html')


@app.route('/hallen')
def zeige_hallen():
    return render_template('hallen.html', hallen=halle_hashmap)

@app.route('/trainer')
def zeige_trainer():
    return render_template('trainer.html', trainer=trainer_hashmap)





if __name__ == '__main__':
    app.run()
