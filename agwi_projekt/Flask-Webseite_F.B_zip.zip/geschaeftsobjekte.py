from dataclasses import dataclass
from datetime import datetime, date


@dataclass
class Adresse:
    adresseId: int
    name: str


@dataclass
class Produkt:
    productId: int
    bildurl: str
    name: str
    bezeichnung: str
    preis: float

@dataclass
class User:
    userid: int
    name: str
    email: str
    password: str


@dataclass
class Trainer:
    trainerId: int
    name: str
    email: str
    birthday: datetime


@dataclass
class Halle:
    halleId: int
    name: str
    opening_time: datetime
    address: Adresse


@dataclass
class Bewertung:
    bewertungId: int
    name: str
    date: date
    points: int
    text: str



halle_hashmap = {}
user_hashmap = {}
trainer_hashmap = {}

adresse1 = Adresse(adresseId=1, name="Hauptstraße 123")
halle1 = Halle(halleId=1, name="Fitness Zentrum A", opening_time=datetime(2024, 12, 14, 8, 0), address=adresse1)
user1 = User(userid=1, name="Max Mustermann", email="max@example.com", password="securepassword")
trainer1 = Trainer(trainerId=1, name="John Doe", email="john.doe@example.com", birthday=datetime(1990, 5, 15))


halle_hashmap[halle1.halleId] = halle1
user_hashmap[user1.userid] = user1
trainer_hashmap[trainer1.trainerId] = trainer1


print(halle_hashmap[1])  # Gibt das Halle-Objekt mit halleId = 1 aus
print(user_hashmap[1])  # Gibt das User-Objekt mit userid = 1 aus
print(trainer_hashmap[1])  # Gibt das Trainer-Objekt mit trainerId = 1 aus

if 1 in halle_hashmap:
    print("Halle mit ID 1 gefunden")


for halle_id, halle_obj in halle_hashmap.items():
    print(f"Halle ID: {halle_id}, Name: {halle_obj.name}")

for user_id, user_obj in user_hashmap.items():
    print(f"User ID: {user_id}, Name: {user_obj.name}")

for trainer_id, trainer_obj in trainer_hashmap.items():
    print(f"Trainer ID: {trainer_id}, Name: {trainer_obj.name}")